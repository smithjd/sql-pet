--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.7 (Debian 10.7-1.pgdg90+1)
-- Dumped by pg_dump version 10.7 (Debian 10.7-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP INDEX hrsample.skills_employee_num;
DROP INDEX hrsample.salhistory;
DROP INDEX hrsample.perfreview_employee_num;
DROP INDEX hrsample.education_employee_num;
DROP INDEX hrsample.contact_employee_num;
ALTER TABLE ONLY hrsample.recruiting_table DROP CONSTRAINT recruiting_table_pkey;
ALTER TABLE ONLY hrsample.hierarchy DROP CONSTRAINT hierarchy_pkey;
ALTER TABLE ONLY hrsample.employeeinfo DROP CONSTRAINT employeeinfo_pkey;
ALTER TABLE ONLY hrsample.deskhistory DROP CONSTRAINT deskhistory_pkey;
DROP TABLE hrsample.skills_table;
DROP TABLE hrsample.salaryhistory;
DROP TABLE hrsample.rollup_view;
DROP TABLE hrsample.recruiting_table;
DROP TABLE hrsample.performancereview;
DROP TABLE hrsample.hierarchy;
DROP TABLE hrsample.employeeinfo;
DROP TABLE hrsample.education_table;
DROP TABLE hrsample.deskjob;
DROP TABLE hrsample.deskhistory;
DROP TABLE hrsample.contact_table;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA hrsample;
--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: hrsample; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hrsample;


ALTER SCHEMA hrsample OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: contact_table; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.contact_table (
    employee_num integer,
    contact_type text,
    contact_sub_type text,
    contact text,
    contact_end_date date
);


ALTER TABLE hrsample.contact_table OWNER TO postgres;

--
-- Name: deskhistory; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.deskhistory (
    employee_num integer NOT NULL,
    desk_id integer NOT NULL,
    desk_id_start_date date NOT NULL,
    desk_id_end_date date,
    termination_flag integer,
    promotion_flag integer
);


ALTER TABLE hrsample.deskhistory OWNER TO postgres;

--
-- Name: deskjob; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.deskjob (
    desk_id integer,
    job_name text
);


ALTER TABLE hrsample.deskjob OWNER TO postgres;

--
-- Name: education_table; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.education_table (
    employee_num integer,
    degree text,
    school_name text
);


ALTER TABLE hrsample.education_table OWNER TO postgres;

--
-- Name: employeeinfo; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.employeeinfo (
    employee_num integer NOT NULL,
    first_name text,
    last_name text,
    city text,
    state text
);


ALTER TABLE hrsample.employeeinfo OWNER TO postgres;

--
-- Name: hierarchy; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.hierarchy (
    desk_id integer NOT NULL,
    org text,
    parent_id integer
);


ALTER TABLE hrsample.hierarchy OWNER TO postgres;

--
-- Name: performancereview; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.performancereview (
    employee_num integer,
    year integer,
    perf_review_score integer
);


ALTER TABLE hrsample.performancereview OWNER TO postgres;

--
-- Name: recruiting_table; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.recruiting_table (
    employee_num integer NOT NULL,
    recruiting_source text,
    first_contact_date date,
    recruiter_employee_num integer
);


ALTER TABLE hrsample.recruiting_table OWNER TO postgres;

--
-- Name: rollup_view; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.rollup_view (
    lvl00_desk_id integer,
    lvl00_org text,
    lvl01_desk_id integer,
    lvl01_org text,
    lvl02_desk_id integer,
    lvl02_org text,
    lvl03_desk_id integer,
    lvl03_org text,
    lvl04_desk_id integer,
    lvl04_org text,
    depth bigint
);


ALTER TABLE hrsample.rollup_view OWNER TO postgres;

--
-- Name: salaryhistory; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.salaryhistory (
    employee_num integer,
    salary_effective_date date,
    salary real,
    salary_increase real,
    starting_salary_flag text
);


ALTER TABLE hrsample.salaryhistory OWNER TO postgres;

--
-- Name: skills_table; Type: TABLE; Schema: hrsample; Owner: postgres
--

CREATE TABLE hrsample.skills_table (
    employee_num integer,
    skill_name text,
    skill_type text
);


ALTER TABLE hrsample.skills_table OWNER TO postgres;

--
-- Data for Name: contact_table; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.contact_table (employee_num, contact_type, contact_sub_type, contact, contact_end_date) FROM stdin;
\.
COPY hrsample.contact_table (employee_num, contact_type, contact_sub_type, contact, contact_end_date) FROM '$$PATH$$/2915.dat';

--
-- Data for Name: deskhistory; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.deskhistory (employee_num, desk_id, desk_id_start_date, desk_id_end_date, termination_flag, promotion_flag) FROM stdin;
\.
COPY hrsample.deskhistory (employee_num, desk_id, desk_id_start_date, desk_id_end_date, termination_flag, promotion_flag) FROM '$$PATH$$/2908.dat';

--
-- Data for Name: deskjob; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.deskjob (desk_id, job_name) FROM stdin;
\.
COPY hrsample.deskjob (desk_id, job_name) FROM '$$PATH$$/2909.dat';

--
-- Data for Name: education_table; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.education_table (employee_num, degree, school_name) FROM stdin;
\.
COPY hrsample.education_table (employee_num, degree, school_name) FROM '$$PATH$$/2916.dat';

--
-- Data for Name: employeeinfo; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.employeeinfo (employee_num, first_name, last_name, city, state) FROM stdin;
\.
COPY hrsample.employeeinfo (employee_num, first_name, last_name, city, state) FROM '$$PATH$$/2907.dat';

--
-- Data for Name: hierarchy; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.hierarchy (desk_id, org, parent_id) FROM stdin;
\.
COPY hrsample.hierarchy (desk_id, org, parent_id) FROM '$$PATH$$/2910.dat';

--
-- Data for Name: performancereview; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.performancereview (employee_num, year, perf_review_score) FROM stdin;
\.
COPY hrsample.performancereview (employee_num, year, perf_review_score) FROM '$$PATH$$/2911.dat';

--
-- Data for Name: recruiting_table; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.recruiting_table (employee_num, recruiting_source, first_contact_date, recruiter_employee_num) FROM stdin;
\.
COPY hrsample.recruiting_table (employee_num, recruiting_source, first_contact_date, recruiter_employee_num) FROM '$$PATH$$/2913.dat';

--
-- Data for Name: rollup_view; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.rollup_view (lvl00_desk_id, lvl00_org, lvl01_desk_id, lvl01_org, lvl02_desk_id, lvl02_org, lvl03_desk_id, lvl03_org, lvl04_desk_id, lvl04_org, depth) FROM stdin;
\.
COPY hrsample.rollup_view (lvl00_desk_id, lvl00_org, lvl01_desk_id, lvl01_org, lvl02_desk_id, lvl02_org, lvl03_desk_id, lvl03_org, lvl04_desk_id, lvl04_org, depth) FROM '$$PATH$$/2914.dat';

--
-- Data for Name: salaryhistory; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.salaryhistory (employee_num, salary_effective_date, salary, salary_increase, starting_salary_flag) FROM stdin;
\.
COPY hrsample.salaryhistory (employee_num, salary_effective_date, salary, salary_increase, starting_salary_flag) FROM '$$PATH$$/2912.dat';

--
-- Data for Name: skills_table; Type: TABLE DATA; Schema: hrsample; Owner: postgres
--

COPY hrsample.skills_table (employee_num, skill_name, skill_type) FROM stdin;
\.
COPY hrsample.skills_table (employee_num, skill_name, skill_type) FROM '$$PATH$$/2917.dat';

--
-- Name: deskhistory deskhistory_pkey; Type: CONSTRAINT; Schema: hrsample; Owner: postgres
--

ALTER TABLE ONLY hrsample.deskhistory
    ADD CONSTRAINT deskhistory_pkey PRIMARY KEY (employee_num, desk_id, desk_id_start_date);


--
-- Name: employeeinfo employeeinfo_pkey; Type: CONSTRAINT; Schema: hrsample; Owner: postgres
--

ALTER TABLE ONLY hrsample.employeeinfo
    ADD CONSTRAINT employeeinfo_pkey PRIMARY KEY (employee_num);


--
-- Name: hierarchy hierarchy_pkey; Type: CONSTRAINT; Schema: hrsample; Owner: postgres
--

ALTER TABLE ONLY hrsample.hierarchy
    ADD CONSTRAINT hierarchy_pkey PRIMARY KEY (desk_id);


--
-- Name: recruiting_table recruiting_table_pkey; Type: CONSTRAINT; Schema: hrsample; Owner: postgres
--

ALTER TABLE ONLY hrsample.recruiting_table
    ADD CONSTRAINT recruiting_table_pkey PRIMARY KEY (employee_num);


--
-- Name: contact_employee_num; Type: INDEX; Schema: hrsample; Owner: postgres
--

CREATE INDEX contact_employee_num ON hrsample.contact_table USING btree (employee_num);


--
-- Name: education_employee_num; Type: INDEX; Schema: hrsample; Owner: postgres
--

CREATE INDEX education_employee_num ON hrsample.education_table USING btree (employee_num);


--
-- Name: perfreview_employee_num; Type: INDEX; Schema: hrsample; Owner: postgres
--

CREATE INDEX perfreview_employee_num ON hrsample.performancereview USING btree (employee_num);


--
-- Name: salhistory; Type: INDEX; Schema: hrsample; Owner: postgres
--

CREATE INDEX salhistory ON hrsample.salaryhistory USING btree (employee_num);


--
-- Name: skills_employee_num; Type: INDEX; Schema: hrsample; Owner: postgres
--

CREATE INDEX skills_employee_num ON hrsample.skills_table USING btree (employee_num);


--
-- PostgreSQL database dump complete
--

